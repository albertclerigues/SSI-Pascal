function awesome_classifier

% change this path if you install the VOC code elsewhere
addpath([cd '/VOCcode']);

% initialize VOC options
VOCinit;

% train and test classifier for each class
for i=1:VOCopts.nclasses
    cls=VOCopts.classes{i};

    [tree, imgMetaData] = SSI_makeBOW(VOCopts, cls);
    classifier=train(VOCopts, imgMetaData, cls); % train classifier
    test(VOCopts,cls,classifier, tree);          % test classifier
    [fp,tp,auc]=VOCroc(VOCopts,'comp1',cls, true);   % compute and display ROC
    
    if i<VOCopts.nclasses
        fprintf('press any key to continue with next class...\n');
        return;
    end
end

% train classifier
function classifier = train(VOCopts, imgMetaData, cls)

% extract features for each image (alreADY in imgMetaData)
vecTrain = zeros(length(imgMetaData), length(imgMetaData(1).hobw));
labTrain = zeros(length(imgMetaData), 1);

tic;
for i=1:length(imgMetaData)
    % display progress
    if toc>1
        fprintf('%s: train: %d/%d\n',cls,i,length(imgMetaData));
        drawnow; tic;
    end
    vecTrain(i,:) = imgMetaData(i).hobw;
    labTrain(i) = imgMetaData(i).gt;
end

Atrain = prdataset(vecTrain,labTrain);
classifier = classc(svc(Atrain));
%classifier = classc(naivebc(Atrain, length(imgMetaData(1).hobw)));

%-----------------------------------------------------------------
% run classifier on test images
function test(VOCopts,cls,classifier, tree)

% load test set ('val' for development kit)
[ids,gt]=textread(sprintf(VOCopts.clsimgsetpath,cls,VOCopts.testset),'%s %d');

% create results file
fid=fopen(sprintf(VOCopts.clsrespath,'comp1',cls),'w');

% classify each image
tic;
for i=1:length(ids)
    % display progress
    if toc>1
        fprintf('%s: test: %d/%d\n',cls,i,length(ids));
        drawnow;
        tic;
    end
    
    try
        % try to load features
        load(sprintf(VOCopts.exfdpath,ids{i}),'fd');
    catch
        % compute and save features
        I=imread(sprintf(VOCopts.imgpath,ids{i}));
        fd=extractfd(VOCopts, I, tree);
        %save(sprintf(VOCopts.exfdpath,ids{i}),'fd');
    end

    % compute confidence of positive classification
    c=classify(VOCopts,classifier,fd);
    
    % write to results file
    fprintf(fid,'%s %f\n',ids{i},c);
end

% close results file
fclose(fid);

% Dense sift feature extractor
function fd = extractfd(VOCopts, I, tree)
I = single(rgb2gray(I));

%Compute DSIFT
opts = VOCopts.dsift;
[~, words] = vl_dsift(I, 'size', opts.binSize, 'step', opts.step, 'FAST');

%Bag words according to dictionary
A = vl_hikmeanspush(tree, words);

%Get HOBW
hobw = vl_hikmeanshist(tree, A);

hobw = hobw./max(hobw);     

fd = hobw(:)';


% trivial classifier: compute ratio of L2 distance betweeen
% nearest positive (class) feature vector and nearest negative (non-class)
% feature vector
function c = classify(VOCopts,classifier,testPRDS)
testPRDS = prdataset(testPRDS);

c = testPRDS*classifier;

c = getdata(c);
c = c(2);

