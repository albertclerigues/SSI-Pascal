function [tree, imgMetaData] = SSI_makeBOW( VOCopts, cls )
% BOW maker
% Get words from all images and classes
[ids,classifier.gt]=textread(sprintf(VOCopts.clsimgsetpath,cls,'train'),'%s %d');

%TODO initialize fullDictionary to some arbitrary number to speed up
%And dinamically increase size in chunks if too small (at the end slice)
fullVocabulary = [];
imgMetaData = struct('filename', '', 'gt', 0, 'numWords', 0, 'hobw', [], 'cls', cls);
imgMetaData(length(ids)).filename = '';

% extract features for each image
tic;
name_cache = 'dsift';
dsift_params = reshape(cell2mat(struct2cell(VOCopts.dsift)),1,[]);
for i = 1:length(dsift_params)
    name_cache = [name_cache '_' int2str(dsift_params(i))];
end
        
try
    % try to load words
    load(sprintf(VOCopts.exfdpath,name_cache),'fullVocabulary', 'imgMetaData');
catch
    for j=1:length(ids)
        % display progress
        if toc > 1
            fprintf('%s: train: %d/%d\n',cls,j,length(ids));
            drawnow; tic;
        end
        
        % compute and save words
        I = imread(sprintf(VOCopts.imgpath,ids{j}));
        I = single(rgb2gray(I));
        
        %Compute DSIFT
        opts = VOCopts.dsift;
        [~, words] = vl_dsift(I, 'size', opts.binSize, 'step', opts.step, 'FAST');
        
        imgMetaData(j).filename = ids{j};
        imgMetaData(j).gt = classifier.gt(j);
        imgMetaData(j).numWords = size(words,2);
        
        fullVocabulary = [fullVocabulary, words];
    end
    
    save(sprintf(VOCopts.exfdpath,name_cache),'fullVocabulary', 'imgMetaData');
end

disp('Full vocabulary built, making dictionary...');

% Cluster vocabulary into BOWs
hikmeans_params = reshape(cell2mat(struct2cell(VOCopts.hikmeans)),1,[]);
name_cache2 = name_cache;
for i = 1:length(hikmeans_params)
    name_cache2 = [name_cache2 '_' int2str(hikmeans_params(i))];
end

try
    % try to load words
    load(sprintf(VOCopts.exdicpath,name_cache2),'tree', 'A');
catch
    opts = VOCopts.hikmeans;
    [tree, A] = vl_hikmeans(fullVocabulary, opts.K, opts.nleaves);
    save(sprintf(VOCopts.exdicpath,name_cache2),'tree', 'A');
end

disp('Dictionary built, bagging train words...');

% Get bagged words for all images and classes
cumWordCount = 1;
for i = 1:length(imgMetaData)
    Ai = A(:, cumWordCount:(cumWordCount+imgMetaData(i).numWords - 1));
    cumWordCount = cumWordCount + imgMetaData(i).numWords;
    
    % Get HOW for all images and classes
    hobw = vl_hikmeanshist(tree, Ai);
    imgMetaData(i).hobw = hobw./max(hobw);
end

disp('Histograms of Bagged Words built!');
end

